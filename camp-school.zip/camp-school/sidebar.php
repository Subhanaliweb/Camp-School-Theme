<?php  /*
This is sidebar page
*/
?>
	<div class="sd-bg-color cm-video-details">
		<?php dynamic_sidebar('main-sidebar'); ?>
	</div>