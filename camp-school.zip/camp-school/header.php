<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Additional CSS Files -->
    <?php
     wp_head();
    ?>
<!--
    
TemplateMo 557 Grad School

https://templatemo.com/tm-557-grad-school

-->
  </head>

<body>
<?php wp_body_open(); ?>
   
  <!--header-->
  <header class="main-header clearfix" role="header">
    <div class="logo">
<?php if( function_exists( 'the_custom_logo' ) ) {
    if(has_custom_logo()) { ?>
      <a href="#"><?php the_custom_logo(); ?></a>
    <?php
    } else {?>
        <a href="#"> <img src="<?php echo esc_url(get_template_directory_uri());?>/assets/img/logo.png"> </a>
        <?php
    }
}
?>
    
    </div>
    <a href="#menu" class="menu-link"><i class="fa fa-bars"></i></a>
    <nav id="menu" class="main-nav" role="navigation">
      <?php             
      wp_nav_menu(array(

        'menu'                 => 'Primary',
        'container'            => '',
        'container_class'      => '',
        'container_id'         => '',
        'container_aria_label' => '',
        'menu_class'           => '',
        'menu_id'              => '',
        'echo'                 => true,
        'fallback_cb'          => 'wp_page_menu',
        'before'               => '',
        'after'                => '',
        'link_before'          => '',
        'link_after'           => '',
        'items_wrap'           => '<ul class="main-menu">%3$s</ul>',
        'item_spacing'         => 'preserve',
        'depth'                => 0,
        'walker'               => '',
        'theme_location' => 'Primary'
            ));
       ?>
    </nav>
  </header>
