<?php 
/* This page is the home page template of website*/
/* Template Name: Home Page */


	 get_header();
	 	if(have_posts()): 
	 		get_template_part('template-parts/home','page');
		endif; 
	 get_footer();