<?php
if ( class_exists( 'Kirki' ) ) {
Kirki::add_config( 'camp-school', array(
	'capability'    => 'edit_theme_options',
	'option_type'   => 'theme_mod',
) );
Kirki::add_section( 'color_section', array(
    'title'          => esc_html__( 'Colors', 'camp-school' ),
    'description'    => esc_html__( 'You can change colors from here.', 'camp-school' ),
    'priority'       => 20,
) );
Kirki::add_section( 'section_titles', array(
    'title'          => esc_html__( 'Section Titles', 'camp-school' ),
    'description'    => esc_html__( 'You can edit Section Title from here.', 'camp-school' ),
    'priority'       => 20,
) );
Kirki::add_panel( 'header_layout', array(
    'title'       => esc_html__( 'Header Section', 'camp-school' ),
    'description' => esc_html__( 'Edit your full header section', 'camp-school' ),
    'priority'    => 20,
) );
Kirki::add_section( 'dot_tabs', array(
    'title'          => esc_html__( 'About Us Section', 'camp-school' ),
    'description'    => esc_html__( 'You can edit your tabs from here.', 'camp-school' ),
    'priority'       => 20,
) );
Kirki::add_section( 'header_video', array(
    'title'          => esc_html__( 'Header Video', 'camp-school' ),
    'description'    => esc_html__( 'You can change your header video from here.', 'camp-school' ),
    'panel'          => 'header_layout',
    'priority'       => 160,
) );
Kirki::add_section( 'Content_and_buttons', array(
    'title'          => esc_html__( 'Content and buttons', 'camp-school' ),
    'description'    => esc_html__( 'Change you header text and button layout', 'camp-school' ),
    'panel'          => 'header_layout',
    'priority'       => 160,
) );
Kirki::add_section( 'features_section', array(
    'title'          => esc_html__( 'Feature Tabs', 'camp-school' ),
    'description'    => esc_html__( 'You can edit your features section from here.', 'camp-school' ),
    'panel'          => 'header_layout',
    'priority'       => 160,
) );
Kirki::add_section( 'timer_section', array(
    'title'          => esc_html__( 'Counter Section', 'camp-school' ),
    'description'    => esc_html__( 'You can edit your Timer section from here.', 'camp-school' ),
    'priority'       => 20,
) );
Kirki::add_section( 'courses_section', array(
    'title'          => esc_html__( 'Courses Section', 'camp-school' ),
    'description'    => esc_html__( 'You can change your background from here further you can add you couses from Dashboard Posts.', 'camp-school' ),
    'priority'       => 20,
) );
Kirki::add_section( 'contact_section', array(
    'title'          => esc_html__( 'Contact Section', 'camp-school' ),
    'description'    => esc_html__( 'You can edit your Contact section from here.', 'camp-school' ),
    'priority'       => 20,
) );
Kirki::add_section( 'footer_section', array(
    'title'          => esc_html__( 'Footer', 'camp-school' ),
    'description'    => esc_html__( 'You can edit footer from here.', 'camp-school' ),
    'priority'       => 20,
) );
Kirki::add_section( 'typography_settings', array(
    'title'          => esc_html__( 'Typography', 'camp-school' ),
    'description'    => esc_html__( 'Text Style & Options.', 'camp-school' ),
    'priority'       => 20,
) );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'first_line_text',
	'label'    => esc_html__( 'Text Control', 'camp-school' ),
	'section'  => 'Content_and_buttons',
	'default'  => esc_html__( 'Graduate School of management', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'code',
	'settings'    => 'header_main_heading',
	'label'       => esc_html__( 'Main Heading', 'camp-school' ),
	'description' => esc_html__( 'Edit your heading', 'camp-school' ),
	'section'     => 'Content_and_buttons',
	'default'     => '<em>Your</em> Classroom',
	'choices'     => [
		'language' => 'css',
	],
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'header_button_text',
	'label'    => esc_html__( 'Button Text ', 'camp-school' ),
	'section'  => 'Content_and_buttons',
	'default'  => esc_html__( 'Discover More', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'link',
	'settings' => 'header_button_url',
	'label'    => __( 'Button Url', 'camp-school' ),
	'section'  => 'Content_and_buttons',
	'default'  => '#section2',
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'tab_1_heading',
	'label'    => esc_html__( 'Tab 1 Heading ', 'camp-school' ),
	'section'  => 'features_section',
	'default'  => esc_html__( 'ALL COURSES', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'textarea',
	'settings' => 'tab_1_text',
	'label'    => esc_html__( 'Tab 1 Para', 'camp-school' ),
	'section'  => 'features_section',
	'default'  => esc_html__( 'Curabitur id eros vehicula, tincidunt libero eu, lobortis mi. In mollis eros a posuere imperdiet. Donec maximus elementum ex. Cras convallis ex rhoncus, laoreet libero eu, vehicula libero.', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'tab_1_button_text',
	'label'    => esc_html__( 'Tab 1 button text', 'camp-school' ),
	'section'  => 'features_section',
	'default'  => esc_html__( 'More Info', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'link',
	'settings' => 'tab_1_button_text_url',
	'label'    => __( 'Tab 1 Button Url', 'camp-school' ),
	'section'  => 'features_section',
	'default'  => '#section2',
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'tab_2_heading',
	'label'    => esc_html__( 'Tab 2 Heading ', 'camp-school' ),
	'section'  => 'features_section',
	'default'  => esc_html__( 'VIRTUAL CLASS', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'textarea',
	'settings' => 'tab_2_text',
	'label'    => esc_html__( 'Tab 2 Para', 'camp-school' ),
	'section'  => 'features_section',
	'default'  => esc_html__( 'Curabitur id eros vehicula, tincidunt libero eu, lobortis mi. In mollis eros a posuere imperdiet. Donec maximus elementum ex. Cras convallis ex rhoncus, laoreet libero eu, vehicula libero.', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'tab_2_button_text',
	'label'    => esc_html__( 'Tab 2 button text', 'camp-school' ),
	'section'  => 'features_section',
	'default'  => esc_html__( 'Details', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'link',
	'settings' => 'tab_2_button_text_url',
	'label'    => __( 'Tab 2 Button Url', 'camp-school' ),
	'section'  => 'features_section',
	'default'  => '#section3',
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'tab_3_heading',
	'label'    => esc_html__( 'Tab 3 Heading ', 'camp-school' ),
	'section'  => 'features_section',
	'default'  => esc_html__( 'REAL MEETING', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'textarea',
	'settings' => 'tab_3_text',
	'label'    => esc_html__( 'Tab 3 Para', 'camp-school' ),
	'section'  => 'features_section',
	'default'  => esc_html__( 'Curabitur id eros vehicula, tincidunt libero eu, lobortis mi. In mollis eros a posuere imperdiet. Donec maximus elementum ex. Cras convallis ex rhoncus, laoreet libero eu, vehicula libero.', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'tab_3_button_text',
	'label'    => esc_html__( 'Tab 3 button text', 'camp-school' ),
	'section'  => 'features_section',
	'default'  => esc_html__( 'Read More', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'link',
	'settings' => 'tab_3_button_text_url',
	'label'    => __( 'Tab 3 Button Url', 'camp-school' ),
	'section'  => 'features_section',
	'default'  => '#section4',
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'link',
	'settings' => 'video_setting_url',
	'label'    => __( 'Video Url', 'camp-school' ),
	'section'  => 'header_video',
	'default'  => 'http://localhost/first/wp-content/uploads/2021/03/course-video.mp4',
	'description' => 'You can also paste your media library video url here',
	'priority' => 10
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'image',
	'settings'    => 'header_image',
	'label'       => esc_html__( 'Background Image', 'camp-school' ),
	'description' => esc_html__( 'Or you can set image.', 'camp-school' ),
	'section'     => 'header_video',
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'dot_1_heading',
	'label'    => esc_html__( 'First Tab Heading', 'camp-school' ),
	'section'  => 'dot_tabs',
	'default'  => esc_html__( 'Best Education', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'dot_2_heading',
	'label'    => esc_html__( 'Second Tab Heading', 'camp-school' ),
	'section'  => 'dot_tabs',
	'default'  => esc_html__( 'Top Management', 'camp-school' ),
	'priority' => 20,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'dot_3_heading',
	'label'    => esc_html__( 'Third Tab Heading', 'camp-school' ),
	'section'  => 'dot_tabs',
	'default'  => esc_html__( 'Quality Meeting', 'camp-school' ),
	'priority' => 30,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'dot_para_1_heading',
	'label'    => esc_html__( 'First Tab Para Heading', 'camp-school' ),
	'section'  => 'dot_tabs',
	'default'  => esc_html__( 'Best Education', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'dot_para_2_heading',
	'label'    => esc_html__( 'Second Tab Para Heading', 'camp-school' ),
	'section'  => 'dot_tabs',
	'default'  => esc_html__( 'Best Education', 'camp-school' ),
	'priority' => 20,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'dot_para_3_heading',
	'label'    => esc_html__( 'Third Tab Para Heading', 'camp-school' ),
	'section'  => 'dot_tabs',
	'default'  => esc_html__( 'Best Education', 'camp-school' ),
	'priority' => 30,
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'code',
	'settings'    => 'dot_1_content',
	'label'       => esc_html__( 'First Tab Content', 'camp-school' ),
	'description' => esc_html__( 'Edit your Paragraph', 'camp-school' ),
	'section'     => 'dot_tabs',
	'default'     => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using <a href="https://paypal.me/camp-school" target="_parent" rel="sponsored">Lorem Ipsum.</a> to Schools. Please tell your friends about us. Thank you.<p>You can modify this Theme layout by editing contents and adding more pages as you needed. Since this theme has options to add dropdown menus, you can put many pages. Suspendisse tincidunt, magna ut finibus rutrum, libero dolor euismod odio, nec interdum quam felis non ante.</p>',
	'priority' => 10,
	'choices'     => [
		'language' => 'html',
	],
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'code',
	'settings'    => 'dot_2_content',
	'label'       => esc_html__( 'First Tab Content', 'camp-school' ),
	'description' => esc_html__( 'Edit your Paragraph', 'camp-school' ),
	'section'     => 'dot_tabs',
	'default'     => 'You are allowed to use this theme to build you website for any purpose. However, magna ut finibus rutrum, libero dolor euismod odio, nec interdum quam felis non ante. You may Get Help<a rel="nofollow" href="https://wordpress.com" target="_parent">Camp Author</a> for details.
	Suspendisse tincidunt, magna ut finibus rutrum, libero dolor euismod odio, nec interdum quam felis non ante.',
	'priority' => 20,
	'choices'     => [
		'language' => 'html',
	],
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'code',
	'settings'    => 'dot_3_content',
	'label'       => esc_html__( 'Third Tab Content', 'camp-school' ),
	'description' => esc_html__( 'Edit your Paragraph', 'camp-school' ),
	'section'     => 'dot_tabs',
	'default'     => 'You can modify this Theme layout by editing contents and adding more pages as you needed. Since this theme has options to add dropdown menus, you can put many pages.
                      Suspendisse tincidunt, magna ut finibus rutrum, libero dolor euismod odio, nec interdum quam felis non ante.',
	'priority' => 30,
	'choices'     => [
		'language' => 'html',
	],
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'image',
	'settings'    => 'dot_1_image',
	'label'       => esc_html__( 'First Tab Image', 'camp-school' ),
	'description' => esc_html__( 'You can change image from here.', 'camp-school' ),
	'section'     => 'dot_tabs',
	'default'     => 'http://localhost/first/wp-content/themes/camp-school/assets/img/choose-us-image-01.png',
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'image',
	'settings'    => 'dot_2_image',
	'label'       => esc_html__( 'Second Tab Image', 'camp-school' ),
	'description' => esc_html__( 'You can change image from here.', 'camp-school' ),
	'section'     => 'dot_tabs',
	'default'     => 'http://localhost/first/wp-content/themes/camp-school/assets/img/choose-us-image-02.png',
	'priority' => 20,
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'image',
	'settings'    => 'dot_3_image',
	'label'       => esc_html__( 'Third Tab Image', 'camp-school' ),
	'description' => esc_html__( 'You can change image from here.', 'camp-school' ),
	'section'     => 'dot_tabs',
	'default'     => 'http://localhost/first/wp-content/themes/camp-school/assets/img/choose-us-image-03.png',
	'priority' => 30,
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'background',
	'settings'    => 'Counter_section_background_setting',
	'label'       => esc_html__( 'Background Control', 'camp-school' ),
	'description' => esc_html__( 'Background conrols', 'camp-school' ),
	'section'     => 'timer_section',
	'default'     => [
		'background-color'      => '',
		'background-image'      => 'http://localhost/first/wp-content/themes/camp-school/assets/img/choosing-bg.jpg',
		'background-repeat'     => 'repeat',
		'background-position'   => 'center center',
		'background-size'       => 'cover',
		'background-attachment' => 'scroll',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'section.why-us',
		],
	],
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'date',
	'settings'    => 'timer_setting',
	'label'       => esc_html__( 'Set Timer Date', 'camp-school' ),
	'description' => esc_html__( 'This is a timer control.', 'camp-school' ),
	'section'     => 'timer_section',
	'default'     => '2022-01-01',
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'code',
	'settings'    => 'timer_heading',
	'label'       => esc_html__( 'Main Heading', 'camp-school' ),
	'description' => esc_html__( 'Edit your heading', 'camp-school' ),
	'section'     => 'timer_section',
	'default'     => 'Take <em>any online course</em> and win $326 for your next class',
	'choices'     => [
		'language' => 'html',
	],
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'code',
	'settings'    => 'presentation_section_heading',
	'label'       => esc_html__( 'Heading', 'camp-school' ),
	'description' => esc_html__( 'Edit your heading', 'camp-school' ),
	'section'     => 'contact_section',
	'default'     => '<span>our presentation is for you</span>
           			  <h4>Watch the video to learn more <em>about camp-school School</em></h4>',
	'choices'     => [
		'language' => 'html',
	],
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'code',
	'settings'    => 'presentation_section_text',
	'label'       => esc_html__( 'Paragraph', 'camp-school' ),
	'description' => esc_html__( 'Edit your content', 'camp-school' ),
	'section'     => 'contact_section',
	'default'     => '<p>You are allowed to use this theme to build you website for any purpose. However, magna ut finibus rutrum, libero dolor euismod odio, nec interdum quam felis non ante. You may Get Help<a rel="nofollow" href="https://wordpress.com" target="_parent">Camp Author</a> for details.
            <br><br>Suspendisse tincidunt, magna ut finibus rutrum, libero dolor euismod odio, nec interdum quam felis non ante.</p>',
	'choices'     => [
		'language' => 'html',
	],
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'presentation_section_button_text',
	'label'    => esc_html__( 'Thumbnail Text', 'camp-school' ),
	'section'  => 'contact_section',
	'default'  => esc_html__( 'Power WordPress Theme', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'presentation_section_button_text',
	'label'    => esc_html__( 'Button Text', 'camp-school' ),
	'section'  => 'contact_section',
	'default'  => esc_html__( 'External URL', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'link',
	'settings' => 'presentation_section_button_link',
	'label'    => __( 'Button Url', 'camp-school' ),
	'section'  => 'contact_section',
	'default'  => 'https://fb.com/camp-school',
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'image',
	'settings'    => 'presentation_main_background',
	'label'       => esc_html__( 'Thumbnail Image', 'camp-school' ),
	'description' => esc_html__( 'You can change thumbnail from here.', 'camp-school' ),
	'section'     => 'contact_section',
	'default'     => 'http://localhost/first/wp-content/themes/camp-school/assets/img/main-thumb.png',
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'link',
	'settings' => 'presentation_section_video_link',
	'label'    => __( 'Video Url', 'camp-school' ),
	'section'  => 'contact_section',
	'default'  => 'https://www.youtube.com/watch?v=r9LtOG6pNUw',
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'link',
	'settings' => 'map_link',
	'label'    => __( 'Map Iframe Url', 'camp-school' ),
	'section'  => 'contact_section',
	'default'  => 'https://maps.google.com/maps?q=Av.+L%C3%BAcio+Costa,+Rio+de+Janeiro+-+RJ,+Brazil&t=&z=13&ie=UTF8&iwloc=&output=embed',
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'color',
	'settings'    => 'body_color',
	'label'       => __( 'Body Color', 'camp-school' ),
	'description' => esc_html__( 'You can change body color from here.', 'camp-school' ),
	'section'     => 'color_section',
	'default'     => '#fff',
	'choices'     => [
		'alpha' => true,
	],
	'output'      => [
		[
			'element' => 'body',
			'property' => 'background-color',
		],
	],
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'color',
	'settings'    => 'header_color',
	'label'       => __( 'Header Color', 'camp-school' ),
	'description' => esc_html__( 'You can change your header color from here.', 'camp-school' ),
	'section'     => 'color_section',
	'default'     => 'rgba(22,34,57,0.95)',
	'choices'     => [
		'alpha' => true,
	],
	'output'      => [
		[
			'element' => '.main-header',
			'property' => 'background-color',
		],
	],
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'color',
	'settings'    => 'color_setting',
	'label'       => __( 'Text Color', 'camp-school' ),
	'description' => esc_html__( 'You can change your text color from here.', 'camp-school' ),
	'section'     => 'color_section',
	'default'     => '#f5a425',
	'choices'     => [
		'alpha' => true,
	],
	'output'      => [
		[
			'element' => '.main-banner .caption h2 em, #tabs ul .ui-tabs-active a, section.coming-soon .continer h4 em, section.coming-soon .continer .counter span, section.courses .item .down-content .text-button-pay a, section.video .left-content h4 em, footer p a, footer p a:hover',
			'property' => 'color',
		],
	],
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'color',
	'settings'    => 'border_color_settings',
	'label'       => __( 'Border Color', 'camp-school' ),
	'description' => esc_html__( 'You can change your border color from here.', 'camp-school' ),
	'section'     => 'color_section',
	'default'     => '#f5a425',
	'choices'     => [
		'alpha' => true,
	],
	'output'      => [
		[
			'element' => 'section.courses .item .down-content img, .main-nav li:hover a, .main-nav li.active a, #tabs ul .ui-tabs-active a:before',
			'property' => 'border-color',
		],
	],
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'color',
	'settings'    => 'main_background_color_settings',
	'label'       => __( 'Background Color', 'camp-school' ),
	'description' => esc_html__( 'You can change your element background color from here.', 'camp-school' ),
	'section'     => 'color_section',
	'default'     => '#f5a425',
	'choices'     => [
		'alpha' => true,
	],
	'output'      => [
		[
			'element' => '.features-content:hover, #tabs ul .ui-tabs-active a:after,  section.courses .owl-carousel button.active',
			'property' => 'background-color',
		],
	],
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'color',
	'settings'    => 'buttons_color_settings',
	'label'       => __( 'Buttons Color', 'camp-school' ),
	'description' => esc_html__( 'You can change your buttons color from here.', 'camp-school' ),
	'section'     => 'color_section',
	'default'     => '#f5a425',
	'choices'     => [
		'alpha' => true,
	],
	'output'      => [
		[
			'element' => '.main-button a, .video-item figure a:before, section.coming-soon form button, section.contact form input.button, section.coming-soon form button, section.contact form input.button',
			'property' => 'background-color',
		],
	],
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'color',
	'settings'    => 'button_text_color',
	'label'       => __( 'Buttons Text Color', 'camp-school' ),
	'description' => esc_html__( 'You can change button text Color', 'camp-school' ),
	'section'     => 'color_section',
	'default'     => '#fff',
	'choices'     => [
	'alpha' => true,
	],
	'output'      => [
		[
			'element' => '.main-button a, .video-item figure a:before, section.coming-soon form button, section.contact form input.button, section.coming-soon form button, section.contact form input.button',
			'property' => 'color',
		],
	],
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'code',
	'settings'    => 'footer_settings',
	'label'       => esc_html__( 'Footer Text', 'camp-school' ),
	'description' => esc_html__( 'Edit your footer', 'camp-school' ),
	'section'     => 'footer_section',
	'default'     => '<p><i class="fa fa-copyright"></i> Copyright 2021 by camp-school School  
           			 | Design: <a href="https://wordpress.com" rel="sponsored" target="_parent">Camp School</a></p>',
	'choices'     => [
		'language' => 'html',
	],
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'background',
	'settings'    => 'Counter_section_background_setting',
	'label'       => esc_html__( 'Background Control', 'camp-school' ),
	'description' => esc_html__( 'Background conrols', 'camp-school' ),
	'section'     => 'timer_section',
	'default'     => [
		'background-color'      => '',
		'background-image'      => 'http://localhost/first/wp-content/uploads/2021/02/video-bg.jpg',
		'background-repeat'     => 'repeat',
		'background-position'   => 'center center',
		'background-size'       => 'cover',
		'background-attachment' => 'scroll',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'section.coming-soon',
		],
	],
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'category_name',
	'label'    => esc_html__( 'Category Name', 'camp-school' ),
	'description' => esc_html__( 'Enter the name of category from which you want to display posts on home page.', 'camp-school' ),
	'section'  => 'courses_section',
	'default'  => esc_html__( 'courses', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'background',
	'settings'    => 'courses_background_settings',
	'label'       => esc_html__( 'Background Control', 'camp-school' ),
	'description' => esc_html__( 'Edit your background', 'camp-school' ),
	'section'     => 'courses_section',
	'default'     => [
		'background-color'      => '',
		'background-image'      => 'http://localhost/first/wp-content/themes/camp-school/assets/img/choosing-bg.jpg',
		'background-repeat'     => 'repeat',
		'background-position'   => 'center center',
		'background-size'       => 'cover',
		'background-attachment' => 'scroll',
	],
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'section.courses',
		],
	],
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'about_us_title',
	'label'    => esc_html__( 'About Us Title', 'camp-school' ),
	'section'  => 'section_titles',
	'default'  => esc_html__( 'Why choose Camp School?', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'courses_title',
	'label'    => esc_html__( 'Courses title', 'camp-school' ),
	'section'  => 'section_titles',
	'default'  => esc_html__( 'Choose Your Course', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'     => 'text',
	'settings' => 'contact_title',
	'label'    => esc_html__( 'Contact Title', 'camp-school' ),
	'section'  => 'section_titles',
	'default'  => esc_html__( 'Let’s Keep In Touch', 'camp-school' ),
	'priority' => 10,
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'typography',
	'settings'    => 'main-heading_typography_setting',
	'label'       => esc_html__( 'Main Heading', 'camp-school' ),
	'section'     => 'typography_settings',
	'default'     => [
		'font-family'    => 'Montserrat',
		'variant'        => 'regular',
		'font-size'      => '64px',	
		'font-weight'	 => '800',
		'letter-spacing' => '1',
		'color'          => '#fff',
		'text-transform' => 'uppercase',
	],
	'choices' => [
	'fonts' => [
		'google'   => [ 'popularity', 50 ],
		'standard' => [
			'Georgia,Times,"Times New Roman",serif',
			'Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif',
		],
	],
],
	'priority'    => 10,
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.main-banner .caption h2',
			'suffix'   => '!important',
		],
	],
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'typography',
	'settings'    => 'title_typography_setting',
	'label'       => esc_html__( 'Section Titles', 'camp-school' ),
	'section'     => 'typography_settings',
	'default'     => [
		'font-family'    => 'Montserrat',
		'variant'        => 'regular',
		'font-size'      => '18px',	
		'font-weight'	 => '500',
		'letter-spacing' => '0.5',
		'color'          => '#fff',
	],
	'choices' => [
	'fonts' => [
		'google'   => [ 'popularity', 50 ],
		'standard' => [
			'Georgia,Times,"Times New Roman",serif',
			'Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif',
		],
	],
],
	'priority'    => 10,
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => '.section-heading h3',
			'suffix'   => '!important',
		],
	],
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'typography',
	'settings'    => 'section_heading_typography_setting',
	'label'       => esc_html__( 'Section Headings', 'camp-school' ),
	'section'     => 'typography_settings',
	'default'     => [
		'font-family'    => 'Montserrat',
		'font-size'      => '30px',	
		'font-weight'	 => '800',
		'letter-spacing' => '0.5',
		'line-height'	 =>'40px',
		'color'          => '#fff',
	],
	'choices' => [
	'fonts' => [
		'google'   => [ 'popularity', 50 ],
		'standard' => [
			'Georgia,Times,"Times New Roman",serif',
			'Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif',
		],
	],
],
	'priority'    => 10,
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'section.video .left-content h4,section.coming-soon .continer h4',
			'suffix'   => '!important',
		],
	],
] );
Kirki::add_field( 'camp-school', [
	'type'        => 'typography',
	'settings'    => 'content_typography_setting',
	'label'       => esc_html__( 'Text', 'camp-school' ),
	'section'     => 'typography_settings',
	'default'     => [
		'font-family'    => 'Montserrat',
		'font-size'      => '13px',	
		'line-height'	 =>'22px',
	],
	'choices' => [
	'fonts' => [
		'google'   => [ 'popularity', 50 ],
		'standard' => [
			'Georgia,Times,"Times New Roman",serif',
			'Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif',
		],
	],
],
	'priority'    => 10,
	'transport'   => 'auto',
	'output'      => [
		[
			'element' => 'p',
			'suffix'   => '!important',
		],
	],
] );
}
