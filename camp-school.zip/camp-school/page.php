<?php
/*
This is a single Page
*/

	 get_header();
	 	if(have_posts()): 
	 		get_template_part('template-parts/pagepart','page');
		endif; 
	 get_footer();