<section class="section main-banner" id="top" data-section="section1">
  <?php $allowed_html = camp_school_shapeSpace_allowed_html(); ?>
    <?php if (!empty(get_theme_mod('header_image'))) {
      ?>    
      <img id="bg-image" src="<?php echo esc_url(get_theme_mod('header_image','')); ?>">
      <?php } 
      else{ ?>
      
      <video autoplay muted loop id="bg-video">
          <source src="<?php echo esc_url(get_theme_mod('video_setting_url','http://localhost/first/wp-content/uploads/2021/03/course-video.mp4')); ?>" type="video/mp4" />
      </video>
    <?php } ?>
      

      <div class="video-overlay header-text">
          <div class="caption">
              <h6><?php echo esc_html(get_theme_mod('first_line_text','Graduate School of management')); ?></h6>
              <h2><?php echo wp_kses(get_theme_mod('header_main_heading','<em>Your</em> Classroom'),$allowed_html); ?></h2>
              <div class="main-button">
                  <div class="scroll-to-section"><a style="color:<?php echo esc_attr(get_theme_mod('button_text_color','#fff')); ?>;"   href="<?php echo esc_url(get_theme_mod('header_button_url','#section2')); ?>"><?php echo esc_html(get_theme_mod('header_button_text','Discover more')); ?></a></div>
              </div>
          </div>
      </div>  
  </section>
  <!-- ***** Main Banner Area End ***** -->
  <section class="features">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-12">
          <div class="features-post">
            <div class="features-content">
              <div class="content-show">
                <h4><i class="fa fa-pencil"></i><?php echo esc_html(get_theme_mod('tab_1_heading','All Courses')); ?></h4>
              </div>
              <div class="content-hide">
                <p><?php echo esc_html(get_theme_mod('tab_1_text','Curabitur id eros vehicula, tincidunt libero eu, lobortis mi. In mollis eros a posuere imperdiet. Donec maximus elementum ex. Cras convallis ex rhoncus, laoreet libero eu, vehicula libero.')); ?></p>
                <div class="scroll-to-section"><a href="<?php echo esc_url(get_theme_mod('tab_1_button_text_url','#section2')); ?>"><?php echo esc_html(get_theme_mod('tab_1_button_text','More Info.')); ?></a></div>
            </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-12">
          <div class="features-post second-features">
            <div class="features-content">
              <div class="content-show">
                <h4><i class="fa fa-graduation-cap"></i><?php echo esc_html(get_theme_mod('tab_2_heading','Virtual Class')); ?></h4>
              </div>
              <div class="content-hide">
                <p><?php echo wp_kses(get_theme_mod('tab_2_text','Curabitur id eros vehicula, tincidunt libero eu, lobortis mi. In mollis eros a posuere imperdiet. Donec maximus elementum ex. Cras convallis ex rhoncus, laoreet libero eu, vehicula libero.</p>
                <p class="hidden-sm">Curabitur id eros vehicula, tincidunt libero eu, lobortis mi. In mollis eros a posuere imperdiet.'), $allowed_html); ?></p>
                <div class="scroll-to-section"><a href="<?php echo esc_url(get_theme_mod('tab_2_button_text_url','#section3')); ?>"><?php echo esc_html(get_theme_mod('tab_2_button_text','Details')); ?></a></div>
            </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-12">
          <div class="features-post third-features">
            <div class="features-content">
              <div class="content-show">
                <h4><i class="fa fa-book"></i><?php echo esc_html(get_theme_mod('tab_3_heading','Real Meeting')); ?></h4>
              </div>
              <div class="content-hide">
                <p><?php echo esc_html(get_theme_mod('tab_3_text','Curabitur id eros vehicula, tincidunt libero eu, lobortis mi. In mollis eros a posuere imperdiet. Donec maximus elementum ex. Cras convallis ex rhoncus, laoreet libero eu, vehicula libero.')); ?></p>
                <div class="scroll-to-section"><a href="<?php echo esc_url(get_theme_mod('tab_3_button_text_url','#section4')); ?>#section4"><?php echo esc_html(get_theme_mod('tab_3_button_text','Read More')); ?></a></div>
            </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <?php $WhyUsBackground = esc_url(get_theme_mod( 'why_choose_us_background', 'http://localhost/first/wp-content/themes/camp-school/assets/img/choosing-bg.jpg')); ?>
  <section class="section why-us" data-section="section2" style="background-image: url(<?php echo esc_url( $WhyUsBackground ); ?>);">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="section-heading">
            <h3><?php echo esc_html(get_theme_mod('about_us_title','Why Choose Camp School?'));?></h3>
          </div>
        </div>
        <div class="col-md-12">
          <div id='tabs'>
            <ul>
              <li><a href='#tabs-1'><?php echo esc_html(get_theme_mod('dot_1_heading','Best Education')); ?></a></li>
              <li><a href='#tabs-2'><?php echo esc_html(get_theme_mod('dot_2_heading','Top Management')); ?></a></li>
              <li><a href='#tabs-3'><?php echo esc_html(get_theme_mod('dot_3_heading','Quality Meeting')); ?></a></li>
            </ul>
            <section class='tabs-content'>
              <article id='tabs-1'>
                <div class="row">
                  <div class="col-md-6">esc_html(
                    <?php echo $image_tab_1 = esc_url(get_theme_mod( 'dot_1_image', 'http://localhost/first/wp-content/themes/camp-school/assets/img/choose-us-image-01.png')); ?>           
                    <img src="<?php echo esc_url( $image_tab_1 ); ?>" alt="">
                  </div>
                  <div class="col-md-6">
                    <h4><?php echo esc_html(get_theme_mod('dot_para_1_heading','Best Education')); ?></h4>
                    <p><?php echo wp_kses(get_theme_mod('dot_1_content','It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using <a href="https://paypal.me/camp-school" target="_parent" rel="sponsored">Paypal</a> to Schools. Please tell your friends about us. Thank you.<p>You can modify this Theme layout by editing contents and adding more pages as you needed. Since this theme has options to add dropdown menus, you can put many pages. Suspendisse tincidunt, magna ut finibus rutrum, libero dolor euismod odio, nec interdum quam felis non ante.</p>'), $allowed_html); ?></p>
                  </div>
                </div>
              </article>  
              <article id='tabs-2'>
                <div class="row">
                  <div class="col-md-6">
                    <?php echo $image_tab_2 = esc_url(get_theme_mod( 'dot_2_image', 'http://localhost/first/wp-content/themes/camp-school/assets/img/choose-us-image-02.png')); ?>           
                    <img src="<?php echo esc_url( $image_tab_2 ); ?>" alt="">
                  </div>
                  <div class="col-md-6">
                    <h4><?php echo esc_html(get_theme_mod('dot_para_2_heading','Top Level')); ?></h4>
                    <p><?php echo esc_html(get_theme_mod('dot_2_content','You can modify this Theme layout by editing contents and adding more pages as you needed. Since this theme has options to add dropdown menus, you can put many pages.
                      Suspendisse tincidunt, magna ut finibus rutrum, libero dolor euismod odio, nec interdum quam felis non ante.'));?></p>
                  </div>
                </div>
              </article>
              <article id='tabs-3'>
                <div class="row">
                  <div class="col-md-6">
                    <?php echo $image_tab_3 = esc_url(get_theme_mod( 'dot_3_image', 'http://localhost/first/wp-content/themes/camp-school/assets/img/choose-us-image-03.png')); ?>           
                    <img src="<?php echo esc_url( $image_tab_3 ); ?>" alt="">
                  </div>
                  <div class="col-md-6">
                    <h4><?php echo esc_html(get_theme_mod('dot_para_3_heading','Quality Meeting')); ?></h4>
                    <p> <?php echo wp_kses(get_theme_mod('dot_3_content','You are allowed to use this theme to build you website for any purpose. However, magna ut finibus rutrum, libero dolor euismod odio, nec interdum quam felis non ante. You may Get Help <a rel="nofollow" href="https://wordpress.com" target="_parent">Camp Author</a> for details.'), $allowed_html); ?> </p>
                  </div>
                </div>
              </article>
            </section>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section coming-soon" data-section="section3">
    <div class="container">
      <div class="row">
        <div class="col-md-7 col-xs-12">
          <div class="continer centerIt">
            <div>
              <h4><?php echo wp_kses(get_theme_mod('timer_heading','Take <em>any online course</em> and win $326 for your next class'),$allowed_html); ?></h4>
              <div class="counter">

                <div class="days">
                  <div class="value">00</div>
                  <span>Days</span>
                </div>

                <div class="hours">
                  <div class="value">00</div>
                  <span>Hours</span>
                </div>

                <div class="minutes">
                  <div class="value">00</div>
                  <span>Minutes</span>
                </div>

                <div class="seconds">
                  <div class="value">00</div>
                  <span>Seconds</span>
                </div>

              </div>
            </div>
          </div>
        </div>
        <div class="col-md-5">
          <div class="right-content">
            <div class="top-content">
              <?php 
              $my_postid = 395;//This is page id or post id
              $title_post = get_post($my_postid);
              $heading = $title_post->post_title;
              $heading = apply_filters('the_title', $heading);
              $heading = str_replace(']]>', ']]&gt;', $heading);
              ?>
              <h6><?php echo $heading; ?></h6>  
            </div>
             <?php
              echo do_shortcode(
                '[contact-form-7 id="395" title="Register your free account and get immediate access to online courses"]'
                );
            ?>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <section class="section courses" data-section="section4">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="section-heading">
            <h3><?php echo esc_html(get_theme_mod('courses_title','Choose Your Course')); ?></h3>
          </div>
        </div>
        <div class="owl-carousel owl-theme">
          <?php $category_name = esc_html(get_theme_mod('category_name','courses')); ?>
<?php     $args = array(
        'posts_per_page' =>-1,
        'category_name' => "$category_name",
    );
    $courses = new WP_Query($args);
        if($courses->have_posts()) :
        while($courses->have_posts()) : $courses->the_post()
         ?>
          <div class="item">
            <img src="<?php echo get_the_post_thumbnail_url(get_the_ID());?>" alt="Course #1">
            <div class="down-content">
              <h4><?php  the_title() ?></h4>
              <?php  the_excerpt() ?>
              <div class="author-image">
                <?php if( get_post_meta( get_the_ID(), 'camp-school_authorauthor-picture', true ) ){ ?>
              <img src="<?php echo get_post_meta( get_the_ID(), 'camp-school_authorauthor-picture', true ) ?>" alt="Author #1" />
                <?php } 
                else { ?>
                <img src="<?php echo esc_url(get_template_directory_uri()); ?> /assets/img/author-01.png"  alt="Author 1">
               <?php } ?>
              </div>
              <div class="text-button-pay">
                <?php if( get_post_meta( get_the_ID(), 'camp-school_authorbutton-url', true ) && get_post_meta( get_the_ID(), 'camp-school_authorbutton-text', true ) ) { ?>
                <a href="<?php echo get_post_meta( get_the_ID(), 'camp-school_authorbutton-url', true ) ;?>" target="_blank" ><?php echo get_post_meta( get_the_ID(), 'camp-school_authorbutton-text', true ) ?> <i class="fa fa-angle-double-right"></i></a>
                <?php }
                elseif( get_post_meta( get_the_ID(), 'camp-school_authorbutton-text', true ) ){ ?>
                <a href="<?php the_permalink() ?>" ><?php echo get_post_meta( get_the_ID(), 'camp-school_authorbutton-text', true ) ?> <i class="fa fa-angle-double-right"></i></a>
                <?php } 
                elseif( get_post_meta( get_the_ID(), 'camp-school_authorbutton-url', true ) ){ ?>
                <a href="<?php echo get_post_meta( get_the_ID(), 'camp-school_authorbutton-url', true ) ;?>" target="_blank" >Pay <i class="fa fa-angle-double-right"></i></a>
                <?php }  
                else { ?>
                  <a href="<?php the_permalink() ?>" >Pay <i class="fa fa-angle-double-right"></i></a>
                  <?php } ?>
              </div>
            </div>
          </div> 
            <?php  
          endwhile;
          endif;
           ?>
          </div>
        </div>
      </div>
    </div>
  </section>  


  <section class="section video" data-section="section5">
    <div class="container">
      <div class="row">
        <div class="col-md-6 align-self-center">
          <div class="left-content">
            <?php echo wp_kses(get_theme_mod('presentation_section_heading','<span>our presentation is for you</span>
            <h4>Watch the video to learn more <em>about Camp School</em></h4>'),$allowed_html); ?>
            <?php echo wp_kses(get_theme_mod('presentation_section_text','<p>You are allowed to use this theme to build you website for any purpose. However, magna ut finibus rutrum, libero dolor euismod odio, nec interdum quam felis non ante. You may Get Help <a rel="nofollow" href="https://wordpress.com" target="_parent">Camp Author</a> for details.
            <br><br>Suspendisse tincidunt, magna ut finibus rutrum, libero dolor euismod odio, nec interdum quam felis non ante.</p>'),$allowed_html); ?>
            <div class="main-button"><a rel="nofollow" href="<?php echo esc_url(get_theme_mod('presentation_section_button_link','https://fb.com/wordpress.com')); ?>" target="_parent"><?php echo esc_html(get_theme_mod('presentation_section_button_text','External URL')); ?></a></div>
          </div>
        </div>
        <div class="col-md-6">
          <article class="video-item">
            <div class="video-caption">
              <h4><?php echo esc_html(get_theme_mod('presentation_section_button_text','Power WordPress Theme')); ?></h4>
            </div>
            <figure>
              <a href="<?php echo esc_url(get_theme_mod('presentation_section_video_link','https://www.youtube.com/watch?v=r9LtOG6pNUw')); ?>" class="play"><img src="<?php echo esc_url(get_theme_mod('presentation_main_background','http://localhost/first/wp-content/themes/camp-school/assets/img/main-thumb.png')); ?>"></a>
            </figure>
          </article>
        </div>
      </div>
    </div>
  </section>
        
<script type="text/javascript">
  // Set the date we're counting down to
    var countDownDate = new Date("<?php
    $timer = esc_html(get_theme_mod( 'timer_setting', '2022-01-01' ));
    echo esc_html( $timer );
    ?>").getTime();

// Update the count down every 1 second
    var x = setInterval(function() {

  // Get today's date and time
    var now = new Date().getTime();
    
  // Find the distance between now and the count down date
    var distance = countDownDate - now;
    
  // Time calculations for days, hours, minutes and seconds
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
      document.querySelector(".days > .value").innerText=days;
      document.querySelector(".hours > .value").innerText=hours;
      document.querySelector(".minutes > .value").innerText=minutes;
      document.querySelector(".seconds > .value").innerText=seconds;
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>
               