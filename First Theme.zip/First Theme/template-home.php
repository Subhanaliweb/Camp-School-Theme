<?php  
/*
This diplay pages Home us temmplate
Template Name: Home Template
*/
?>
<?php get_header() ?>
		<div class="container-fluid bg-1 text-center">
		  <h3 class="margin">Who Am I?</h3>
		  <img src="<?php header_image(); ?>" class="img-responsive img-circle margin" style="display:inline" alt="Bird" width="350" height="350">
		  <h3>I'm an adventurer</h3>
		</div>	
<div class="text-center">
<?php 
		if ( have_posts() ) : 
		    while ( have_posts() ) : the_post(); ?>
		       <p><?php the_content()?></p>
		    <?php endwhile; 
		endif; 
?>
</div>
<div class="section-head"><h3>Post From Technology</h3></div>
<div class="section-content container">
	<?php 
	$args = array(
		'cat' => 3
	);
	$seabird = new Wp_Query($args);
	if( $seabird-> have_posts()):
		while($seabird->have_posts()): $seabird->the_post();
 ?>
 <div class="row-flex">
 <div class="col-3 "><?php echo the_post_thumbnail('thumbnail'); ?></div>
 <div class="col-9"><h3><a href="<?php echo get_the_permalink(get_the_ID()); ?>"><?php the_title() ?></a></h3></div>
 </div>
<?php endwhile; endif; ?>
</div>

<?php get_footer() ?>