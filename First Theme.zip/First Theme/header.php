<?php  
/*
This diplay header template part
*/
?>
<!DOCTYPE html>
<html>
<meta charset="utf-8"> 
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
	<?php wp_head() ?>
</head>
<body>
<nav class="navbar navbar-default">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
     <?php the_custom_logo(); ?>
    </div>
    <!-- <div class="collapse navbar-collapse" id="myNavbar"> -->
      <!-- <ul class="nav navbar-nav navbar-right">
        <li><a href="#">WHO</a></li>
        <li><a href="#">WHAT</a></li>
        <li><a href="#">WHERE</a></li>
      </ul> -->
      <?php wp_nav_menu(array(
    // 'menu'              => 'primary', // match name to yours
    'theme_location'    => 'primary',
    'container'         => 'div', // no need to wrap `wp_nav_menu` manually
    'container_class'   => 'collapse navbar-collapse',
    'container_id'      => 'myNavbar',
    'items_wrap' => '<ul class="nav navbar-nav navbar-right">%3$s</ul>'
      ));  ?>
      
    </div>
  </div>
</nav>