<?php 
/*
*
THis show the template part
*
*/
 ?>

 <h1>Assalam-o-Aliekum Every One</h1>	