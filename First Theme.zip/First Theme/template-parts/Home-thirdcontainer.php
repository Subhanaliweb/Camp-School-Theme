  <!-- Third Container (Grid) -->
<div class="container-fluid bg-3 text-center">    
  <h3 class="margin">Where To Find Me?</h3><br>
  <!-- <div class="row">
    <div class="col-sm-4">
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
      <img src="https://www.w3schools.com/bootstrap/birds1.jpg" class="img-responsive margin" style="width:100%" alt="Image">
    </div>
    <div class="col-sm-4"> 
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
      <img src="https://www.w3schools.com/bootstrap/birds2.jpg" class="img-responsive margin" style="width:100%" alt="Image">
    </div>
    <div class="col-sm-4"> 
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
      <img src="https://www.w3schools.com/bootstrap/birds3.jpg" class="img-responsive margin" style="width:100%" alt="Image">
    </div>
  </div> -->
  <?php if(have_posts()) :
  while(have_posts()) : the_post(); ?>
    <div class="posts mb-20">
    <div class=" post-header col-sm-4">
      <div class="post-thumbnail row">
       <a href="<?php the_permalink() ?>"> <?php the_post_thumbnail('full'); ?></a>
      </div>
      <a href="<?php the_permalink() ?>"><h1><?php the_title();?></h1></a> 
      <p><?php the_excerpt();?></p>
      <strong>Author</strong><span class="ml-5"><?php the_author();?></span><strong>Posted:</strong><span class="ml-5"><?php the_time() ?></span>
    </div>
    <div class="post-description"></div>
    <div class="post-footer"></div>
  </div>
<?php endwhile;
      endif; ?>
      <div class="pagination row ml-0 mr-0">
        <?php echo paginate_links( string $args = 'base' ); ?> 
</div>

  
</div>
