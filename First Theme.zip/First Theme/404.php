<?php  
/*
404  File
*/
?>
<?php get_header() ?>

//content here

<?php get_footer() ?>