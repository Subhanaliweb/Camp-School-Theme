<?php  
/*
This diplay archives template
*/
?>
<?php get_header() ?>

//content here

<?php get_footer() ?>