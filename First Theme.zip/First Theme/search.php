<?php  
/*
This diplay search template
*/
?>
<?php get_header() ?>

//content here

<?php get_footer() ?>