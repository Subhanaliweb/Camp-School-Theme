<?php  
/*
This diplay sidebar template
*/
?>