<div class="container-fluid tm-container-content tm-mt-60">
        <div class="row mb-4">
            <?php 
if(have_posts()):
    while(have_posts()): the_post();
             ?>
            <h2 class="col-6 tm-text-primary">
                <?php the_title(); ?>
            </h2>
        <?php endwhile; endif; ?>
            <div class="col-6 d-flex justify-content-end align-items-center">
                <form action="" class="tm-text-primary">
                    Page <input type="text" value="1" size="1" class="tm-input-paging tm-text-primary"> of 200
                </form>
            </div>
        </div>
        <div class="row tm-mb-90 tm-gallery">
        <?php 
// $args= array(
// 'cat' => 5
// );
$all_posts = new Wp_Query(array('post_type'=>'post', 'post_status'=>'publish', 'posts_per_page'=>-1));
if ($all_posts->have_posts()):
  while($all_posts->have_posts()) : $all_posts->the_post()
 ?>
        	<div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-5">
                <figure class="effect-ming tm-video-item">
                    <img height="176px" src=" <?php the_post_thumbnail_url(); ?>" alt="Image" class="img-fluid">
                    <figcaption class="d-flex align-items-center justify-content-center">
                        <h2><?php the_title(); ?></h2>
                        <a href="photo-detail.html">View more</a>
                    </figcaption>                    
                </figure>
                <div class="d-flex justify-content-between tm-text-gray">
                    <span class="tm-text-gray-light"><?php the_date(); ?></span>
                    <span><?php echo (int) get_post_meta(get_the_ID(), 'post_views_count', true) . ' Views'; ?>
                    </span>
                </div>
            </div>
        
    <?php   endwhile;
            endif;
     ?>
     </div>         
         <!-- row -->
     <div class="row tm-mb-90">
            <div class="col-12 d-flex justify-content-between align-items-center tm-paging-col">
                <a href="javascript:void(0);" class="btn btn-primary tm-btn-prev mb-2 disabled">Previous</a>
                <div class="tm-paging d-flex">
                    <?php echo paginate_links(); ?> 
                    <!-- <a href="javascript:void(0);" class="active tm-paging-link"><?php paginate_links(); ?></a>
                    <a href="javascript:void(0);" class="tm-paging-link">2</a>
                    <a href="javascript:void(0);" class="tm-paging-link">3</a>
                    <a href="javascript:void(0);" class="tm-paging-link">4</a> -->
                </div>
                <a href="javascript:void(0);" class="btn btn-primary tm-btn-next">Next Page</a>
            </div>            
        </div>
    </div> <!-- container-fluid, tm-container-content -->
