 <?php /**
 
 This is a function file.

 **/
  ?>
  <?php 
  function subhan_scripts(){
  wp_enqueue_style('style',get_stylesheet_uri());
  wp_enqueue_style('bootstrap',get_template_directory_uri().'/assets/css/bootstrap.min.css');
  wp_enqueue_style('templatemo-style',get_template_directory_uri().'/assets/css/templatemo-style.css');
  wp_enqueue_style('all',get_template_directory_uri().'/assets/fontawesome/css/all.min.css');
  }
  function subhan_script_footer(){
  	wp_enqueue_script('plugins',get_template_directory_uri(),'/assets/js/plugins.js',array(),false,true);
  }
  function subhan_after_theme_setup(){
  	add_theme_support('custom-logo');
  	add_theme_support('title-tag');
  	add_theme_support('automatic-feed-link');
  	add_theme_support('post-thumbnails');
  	register_nav_menus(array(
  	'main' => __('Main Menu','catalog')
  	));
  }

  add_action('after_setup_theme','subhan_after_theme_setup');
  add_action('wp_enqueue_scripts','subhan_scripts');
  add_action('wp_enqueue_scripts','subhan_script_footer');
  function atg_menu_classes($classes, $item, $args) {
  if($args->theme_location == 'main') {
    $classes[] = 'nav-item';
  }
  return $classes;
}
add_filter('nav_menu_css_class', 'atg_menu_classes', 1, 3);
function add_menuclass($ulclass) {
    return preg_replace('/rel="fancybox"/', 'class="nav-link nav-link-1 active"', $ulclass, -1);
}
add_filter('wp_nav_menu','add_menuclass');
function ci_paging_request($wp)
{
	//We don't want to mess with the admin panel.
	if(is_admin()) return;

	$num = get_option('posts_per_page', 15);

	if( is_home() )
		$num = 12;

	if( is_archive() )
		$num = 12;

	if( is_category() or is_tag() )
		$num = 10;

	if( is_category('exotic-flowers') )
		$num = -1; // -1 means No limit

	if( ! isset( $wp->query_vars['posts_per_page'] ) )
	{
		$wp->query_vars['posts_per_page'] = $num;
	}
}
  

   ?>

